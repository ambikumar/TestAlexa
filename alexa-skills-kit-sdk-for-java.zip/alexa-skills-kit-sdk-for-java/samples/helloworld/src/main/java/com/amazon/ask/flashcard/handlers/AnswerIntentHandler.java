package com.amazon.ask.flashcard.handlers;


import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.IntentRequest;
import java.util.Map;

import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

public class AnswerIntentHandler implements RequestHandler {

    @Override
    public boolean canHandle(HandlerInput input) {
        return input.matches(intentName("answerIntent"));
    }

    @Override
    public Optional<Response> handle(HandlerInput input) {
        Map<String, Object> sessionAttributes = input.getAttributesManager().getSessionAttributes();

        String responseText;
        String speechOutput;

//        Map<String, String> quizItem = (LinkedHashMap<String, String>) sessionAttributes.get(Attributes.QUIZ_ITEM_KEY);
//        State state = MAPPER.convertValue(quizItem, State.class);

        IntentRequest intentRequest = (IntentRequest) input.getRequestEnvelope().getRequest();
        boolean correct = true;

        speechOutput = "You scored 100%";
        return input.getResponseBuilder()
                .withSpeech(speechOutput)
                .withShouldEndSession(true)
                .build();
    }
}