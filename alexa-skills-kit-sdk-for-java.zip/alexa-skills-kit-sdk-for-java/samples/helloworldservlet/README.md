# Alexa Skills Kit SDK Sample - Hello World Servlet
A simple Servlet example that demonstrates how to use the Alexa SkillServlet. 

For more information, please refer to [Developing Your First Skill](https://github.com/alexa/alexa-skills-kit-sdk-for-java/wiki/Developing-Your-First-Skill) for detailed instructions.
